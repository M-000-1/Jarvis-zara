package com.manojboss.jarvis

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

data class Mod(val name:String,val icon:ImageVector,val desc:String)
class MainActivity:ComponentActivity(){
 private val mic=registerForActivityResult(ActivityResultContracts.RequestPermission()){if(it)voice()}
 fun requestVoice(){if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED)voice() else mic.launch(Manifest.permission.RECORD_AUDIO)}
 private fun voice(){if(!SpeechRecognizer.isRecognitionAvailable(this)){Toast.makeText(this,"Voice recognition unavailable",Toast.LENGTH_SHORT).show();return};startActivityForResult(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);putExtra(RecognizerIntent.EXTRA_LANGUAGE,Locale.getDefault());putExtra(RecognizerIntent.EXTRA_PROMPT,"Speak a JARVIS command")},101)}
 override fun onCreate(b:Bundle?){super.onCreate(b);setContent{App(this)}}
}

val modules=listOf(
 Mod("Phone Control",Icons.Default.PhoneAndroid,"Android settings and supported phone actions"),Mod("Call Assistant",Icons.Default.Call,"Normal dialer and call safety"),Mod("Web Research",Icons.Default.Language,"Open browser for research"),Mod("Security Center",Icons.Default.Security,"Basic privacy and security checks"),Mod("Wi-Fi Security",Icons.Default.Wifi,"Authorized Wi-Fi safety checks"),Mod("Network Security",Icons.Default.Hub,"Authorized network/lab checks"),Mod("Password Lab",Icons.Default.Password,"Local password strength analysis"),Mod("Email Security",Icons.Default.Email,"MFA and phishing safety"),Mod("CCTV Security",Icons.Default.Videocam,"Own/authorized camera security"),Mod("Cyber Training",Icons.Default.School,"Safe defensive cyber learning"),Mod("Programming Lab",Icons.Default.Code,"Programming and secure coding"),Mod("Teach Me",Icons.Default.AutoStories,"JARVIS teaches you"),Mod("Teach JARVIS",Icons.Default.Psychology,"Your notes and rules"),Mod("JARVIS Ideas",Icons.Default.Lightbulb,"Future upgrade ideas"),Mod("Tasks & Automation",Icons.Default.TaskAlt,"Tasks and safe routines"),Mod("Knowledge Vault",Icons.Default.Bookmark,"Saved notes and research"),Mod("Screen Control",Icons.Default.TouchApp,"Accessibility-based actions"),Mod("3D Character",Icons.Default.Face,"Mini assistant character"),Mod("Privacy & Permissions",Icons.Default.Lock,"Review app permissions"),Mod("Settings",Icons.Default.Settings,"Assistant settings"))

@Composable fun App(ctx:MainActivity){var zara by remember{mutableStateOf(true)};var sel by remember{mutableStateOf<Mod?>(null)};MaterialTheme(colorScheme=darkColorScheme(primary=Color(0xFF00E676),background=Color(0xFF05070A),surface=Color(0xFF0B1117))){Surface(Modifier.fillMaxSize(),color=Color(0xFF05070A)){if(sel==null)Home(ctx,zara,{zara=it},{sel=it})else Detail(ctx,sel!!){sel=null}}}}
@Composable fun Home(ctx:MainActivity,zara:Boolean,mode:(Boolean)->Unit,open:(Mod)->Unit){Column(Modifier.fillMaxSize().padding(16.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("JARVIS // PERSONAL CYBER CORE",color=Color(0xFF00E676),fontSize=19.sp);IconButton({open(modules.last())}){Icon(Icons.Default.Settings,null,tint=Color(0xFF00E676))}};Text("MANOJ BOSS",color=Color.White);Spacer(Modifier.height(14.dp));Card(colors=CardDefaults.cardColors(Color(0xFF0B1117)),shape=RoundedCornerShape(25.dp)){Column(Modifier.fillMaxWidth().padding(20.dp),horizontalAlignment=Alignment.CenterHorizontally){Text(if(zara)"ZARA":"JARVIS",color=Color(0xFF00E676),fontSize=31.sp);Text("ONLINE • CORE READY",color=Color(0xFF00E676));Spacer(Modifier.height(10.dp));Row{Button({mode(false)}){Text("JARVIS 🤖")};Spacer(Modifier.width(8.dp));Button({mode(true)}){Text("ZARA 👩")}};Spacer(Modifier.height(8.dp));Button({ctx.requestVoice()},Modifier.fillMaxWidth()){Icon(Icons.Default.Mic,null);Spacer(Modifier.width(7.dp));Text("VOICE COMMAND")}}};Spacer(Modifier.height(12.dp));Text("MODULES",color=Color(0xFF00E676),fontSize=18.sp);Spacer(Modifier.height(7.dp));LazyVerticalGrid(columns=GridCells.Fixed(2),verticalArrangement=Arrangement.spacedBy(8.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){items(modules){m->Card(Modifier.clickable{open(m)},colors=CardDefaults.cardColors(Color(0xFF0B1117))){Column(Modifier.padding(12.dp)){Icon(m.icon,null,tint=Color(0xFF00E676));Text(m.name,color=Color.White);Text(m.desc,color=Color.LightGray,fontSize=10.sp)}}}}}}
@Composable fun Detail(ctx:Context,m:Mod,back:()->Unit){var p by remember{mutableStateOf("")};Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)){Row(verticalAlignment=Alignment.CenterVertically){IconButton(back){Icon(Icons.Default.ArrowBack,null,tint=Color.White)};Text(m.name,color=Color(0xFF00E676),fontSize=22.sp)};Spacer(Modifier.height(12.dp));when(m.name){"Phone Control"->Action("Open Android Settings","Uses official Android Settings."){ctx.startActivity(Intent(Settings.ACTION_SETTINGS))};"Call Assistant"->Action("Open Phone Dialer","No hidden calling or recording."){ctx.startActivity(Intent(Intent.ACTION_DIAL))};"Web Research"->Action("Open Browser","Starts a safe web search."){ctx.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/search?q=JARVIS+research")))};"Wi-Fi Security"->Action("Open Wi-Fi Settings","Review your own network settings."){ctx.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))};"Privacy & Permissions"->Action("Open App Permissions","Review JARVIS permissions."){ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:${ctx.packageName}")))};"Password Lab"->{OutlinedTextField(p,{p=it},label={Text("Test password")},modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(10.dp));Text("Strength: ${score(p)}",color=Color(0xFF00E676),fontSize=20.sp);Text("Local analysis only; no account cracking.",color=Color.LightGray)};"Security Center"->{val mic=ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED;val cam=ctx.checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED;Info("Basic privacy check","Microphone: ${if(mic)"GRANTED"else"NOT GRANTED"}
Camera: ${if(cam)"GRANTED"else"NOT GRANTED"}

Android does not expose the full device security state to normal apps.")};"3D Character"->Info("Mini Character","◉‿◉

Friendly, non-realistic game-style character. A true floating 3D overlay needs extra assets and Android permissions.");"Email Security"->Info("Email Security","Enable MFA/2FA, review recovery options and recent alerts, remove unknown connected apps, and use your provider's official security page.");"CCTV Security"->Info("CCTV Security","Own/authorized cameras only. Use the manufacturer's official recovery/reset process for forgotten passwords; keep firmware updated and remote access protected.");"Network Security","Wi-Fi Security"->Info(m.name,"Use only your own or explicitly authorized networks/labs. Future versions can add safe inventory/configuration checks.");else->Info(m.name,m.desc+"

This module is included in the single-app architecture and is ready for incremental feature expansion.")}}}
@Composable fun Action(t:String,d:String,a:()->Unit){Card(colors=CardDefaults.cardColors(Color(0xFF0B1117))){Column(Modifier.padding(18.dp)){Text(t,color=Color.White,fontSize=19.sp);Text(d,color=Color.LightGray);Spacer(Modifier.height(12.dp));Button(a){Text("OPEN / RUN")}}}}
@Composable fun Info(t:String,d:String){Card(colors=CardDefaults.cardColors(Color(0xFF0B1117))){Column(Modifier.padding(18.dp)){Text(t,color=Color(0xFF00E676),fontSize=20.sp);Spacer(Modifier.height(8.dp));Text(d,color=Color.White,fontSize=16.sp)}}}
fun score(p:String)=if(p.isEmpty())"Enter a password" else {var s=0;if(p.length>=8)s++;if(p.length>=12)s++;if(p.any{it.isUpperCase()})s++;if(p.any{it.isLowerCase()})s++;if(p.any{it.isDigit()})s++;if(p.any{!it.isLetterOrDigit()})s++;when{ s<=2->"Weak";s<=4->"Medium";else->"Strong"}}
