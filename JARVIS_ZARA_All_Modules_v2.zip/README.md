# JARVIS/ZARA All Modules v2

Single Android project with real module navigation and several safe working actions: voice input foundation, Android settings/dialer/browser launchers, password strength analysis, privacy permission checks, learning/security/cyber/programming modules, knowledge/tasks/ideas screens, and a mini-character screen. Security functions are for owned/authorized systems only. Android permissions and platform restrictions apply.
