package com.manojboss.jarvis

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

data class AppModule(val title: String, val icon: ImageVector, val desc: String)

class MainActivity : ComponentActivity() {
    private val micPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startVoice() else Toast.makeText(this, "Microphone permission is needed for voice input.", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JarvisApp() }
    }

    fun requestVoice() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startVoice()
        else micPermission.launch(Manifest.permission.RECORD_AUDIO)
    }

    private fun startVoice() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Voice recognition is not available on this phone.", Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak a JARVIS command")
        }
        startActivityForResult(intent, 101)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 101) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) Toast.makeText(this, "Command: $spoken", Toast.LENGTH_LONG).show()
        }
    }
}

@Composable
fun JarvisApp() {
    val context = LocalContext.current
    var zara by remember { mutableStateOf(true) }
    var selected by remember { mutableStateOf<AppModule?>(null) }
    var password by remember { mutableStateOf("") }

    val modules = listOf(
        AppModule("Phone Control", Icons.Default.PhoneAndroid, "Open supported Android settings"),
        AppModule("Call Assistant", Icons.Default.Call, "Open the normal phone dialer"),
        AppModule("Web Research", Icons.Default.Language, "Open browser research"),
        AppModule("Security Center", Icons.Default.Security, "Basic privacy checks"),
        AppModule("Wi-Fi Security", Icons.Default.Wifi, "Open Wi-Fi settings"),
        AppModule("Network Security", Icons.Default.Hub, "Authorized lab guidance"),
        AppModule("Password Lab", Icons.Default.Password, "Local password strength check"),
        AppModule("Email Security", Icons.Default.Email, "MFA and phishing guidance"),
        AppModule("CCTV Security", Icons.Default.Videocam, "Own/authorized camera guidance"),
        AppModule("Cyber Training", Icons.Default.School, "Safe defensive cyber lab"),
        AppModule("Programming Lab", Icons.Default.Code, "Programming learning hub"),
        AppModule("Teach Me", Icons.Default.AutoStories, "JARVIS teaches you"),
        AppModule("Teach JARVIS", Icons.Default.Psychology, "Add your own learning notes"),
        AppModule("JARVIS Ideas", Icons.Default.Lightbulb, "Future improvement ideas"),
        AppModule("Tasks & Automation", Icons.Default.TaskAlt, "Safe reminders and routines"),
        AppModule("Knowledge Vault", Icons.Default.Bookmark, "Save notes and research"),
        AppModule("Screen Control", Icons.Default.TouchApp, "Accessibility-based controls"),
        AppModule("3D Character", Icons.Default.Face, "Mini assistant character"),
        AppModule("Privacy & Permissions", Icons.Default.Lock, "Review app permissions"),
        AppModule("Settings", Icons.Default.Settings, "Assistant settings")
    )

    MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF00E676), background = Color(0xFF05070A), surface = Color(0xFF0B1117))) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFF05070A)) {
            if (selected == null) Dashboard(context, zara, { zara = it }, modules) { selected = it }
            else ModuleScreen(selected!!, password, { password = it }, { selected = null }, context)
        }
    }
}

@Composable
fun Dashboard(context: Context, zara: Boolean, onMode: (Boolean) -> Unit, modules: List<AppModule>, onModule: (AppModule) -> Unit) {
    val activity = context as MainActivity
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("JARVIS // PERSONAL CYBER CORE", color = Color(0xFF00E676), fontSize = 20.sp, fontWeight = FontWeight.Bold)
            IconButton({ onModule(AppModule("Settings", Icons.Default.Settings, "Assistant settings")) }) { Icon(Icons.Default.Settings, "Settings", tint = Color(0xFF00E676)) }
        }
        Text("MANOJ BOSS", color = Color.White)
        Spacer(Modifier.height(14.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1117)), shape = RoundedCornerShape(28.dp)) {
            Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(if (zara) "ZARA" else "JARVIS", color = Color(0xFF00E676), fontSize = 32.sp, fontWeight = FontWeight.Bold)
                Text("ONLINE • CORE READY", color = Color(0xFF00E676))
                Spacer(Modifier.height(10.dp))
                Row {
                    Button({ onMode(false) }) { Text("JARVIS 🤖") }
                    Spacer(Modifier.width(8.dp))
                    Button({ onMode(true) }) { Text("ZARA 👩") }
                }
                Spacer(Modifier.height(8.dp))
                Button({ activity.requestVoice() }, modifier = Modifier.fillMaxWidth()) { Text("🎙 VOICE COMMAND") }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("MODULES", color = Color(0xFF00E676), fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Spacer(Modifier.height(6.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(2), verticalArrangement = Arrangement.spacedBy(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxSize()) {
            items(modules) { m ->
                Card(modifier = Modifier.fillMaxWidth().clickable { onModule(m) }, colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1117))) {
                    Column(Modifier.padding(14.dp)) {
                        Icon(m.icon, null, tint = Color(0xFF00E676))
                        Spacer(Modifier.height(6.dp))
                        Text(m.title, color = Color.White, fontWeight = FontWeight.Bold)
                        Text(m.desc, color = Color.LightGray, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun ModuleScreen(module: AppModule, password: String, onPassword: (String) -> Unit, back: () -> Unit, context: Context) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(back) { Icon(Icons.Default.ArrowBack, "Back", tint = Color.White) }
            Text(module.title, color = Color(0xFF00E676), fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(10.dp))
        when (module.title) {
            "Phone Control" -> ActionCard("Open Android Settings", "Official Android settings screen.") { context.startActivity(Intent(Settings.ACTION_SETTINGS)) }
            "Call Assistant" -> ActionCard("Open Phone Dialer", "Uses the normal Android dialer; no hidden recording.") { context.startActivity(Intent(Intent.ACTION_DIAL)) }
            "Web Research" -> ActionCard("Open Browser", "Start a web search.") { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=JARVIS+research"))) }
            "Security Center" -> InfoCard("Privacy Check", "Microphone: ${permissionState(context, Manifest.permission.RECORD_AUDIO)}\nCamera: ${permissionState(context, Manifest.permission.CAMERA)}\n\nA normal Android app cannot inspect every security setting.")
            "Wi-Fi Security" -> ActionCard("Open Wi-Fi Settings", "Review your own network settings.") { context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) }
            "Network Security" -> InfoCard("Authorized Lab Only", "Use only on your own devices or explicitly authorized labs. Future versions can add safe inventory and configuration checks.")
            "Password Lab" -> {
                OutlinedTextField(password, onPassword, label = { Text("Test password") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(10.dp)); Text("Strength: ${passwordScore(password)}", color = Color(0xFF00E676), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Local strength analysis only; no password cracking.", color = Color.LightGray)
            }
            "Email Security" -> InfoCard("Email Security", "Enable MFA/2FA, review recovery options, recent security alerts and connected apps. Use your provider's official security controls.")
            "CCTV Security" -> InfoCard("Own / Authorized Cameras", "Use unique passwords, updates and official recovery/reset procedures. No unauthorized access.")
            "Cyber Training" -> InfoCard("Safe Cyber Lab", "Practice on dummy targets, CTFs, your own devices or explicitly authorized labs.")
            "Programming Lab" -> InfoCard("Programming", "Learn Python, Kotlin/Java, JavaScript, HTML/CSS, SQL, Linux basics and Git.")
            "Teach Me" -> InfoCard("Teach Me", "JARVIS can teach topics step-by-step, including programming, history, psychology and defensive cybersecurity.")
            "Teach JARVIS" -> InfoCard("Teach JARVIS", "Future versions can save your notes and rules into a local Knowledge Vault.")
            "JARVIS Ideas" -> InfoCard("Ideas", "Next upgrades: persistent memory, richer command routing, tasks, offline commands and expressive character reactions.")
            "Tasks & Automation" -> InfoCard("Safe Automation", "Use reminders and non-sensitive routines. Sensitive actions should require confirmation.")
            "Knowledge Vault" -> InfoCard("Knowledge Vault", "Save research notes, links and learning material for later retrieval.")
            "Screen Control" -> InfoCard("Screen Control", "Selected UI actions can use Android Accessibility APIs after explicit user enablement; Android restrictions apply.")
            "3D Character" -> InfoCard("Mini Character", "Friendly non-realistic character. A true floating 3D overlay needs additional assets and Android permissions.")
            "Privacy & Permissions" -> ActionCard("Open App Settings", "Review JARVIS/ZARA permissions.") { context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))) }
            "Settings" -> InfoCard("Assistant Settings", "JARVIS/ZARA mode, voice preferences, confirmations, privacy permissions and personality controls.")
            else -> InfoCard(module.title, module.desc)
        }
    }
}

@Composable fun ActionCard(title: String, desc: String, action: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1117))) {
        Column(Modifier.padding(18.dp)) { Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold); Text(desc, color = Color.LightGray); Spacer(Modifier.height(10.dp)); Button(action) { Text("OPEN / RUN") } }
    }
}

@Composable fun InfoCard(title: String, desc: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1117))) {
        Column(Modifier.padding(18.dp)) { Text(title, color = Color(0xFF00E676), fontSize = 20.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp)); Text(desc, color = Color.White, fontSize = 16.sp) }
    }
}

fun permissionState(context: Context, permission: String): String = if (context.checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED) "GRANTED" else "NOT GRANTED"

fun passwordScore(p: String): String {
    if (p.isEmpty()) return "Enter a password"
    var s = 0
    if (p.length >= 8) s++
    if (p.length >= 12) s++
    if (p.any { it.isUpperCase() }) s++
    if (p.any { it.isLowerCase() }) s++
    if (p.any { it.isDigit() }) s++
    if (p.any { !it.isLetterOrDigit() }) s++
    return when { s <= 2 -> "Weak"; s <= 4 -> "Medium"; else -> "Strong" }
}
