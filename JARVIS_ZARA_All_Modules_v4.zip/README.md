# JARVIS/ZARA All Modules v3

Fixed Kotlin syntax/structure from v2. This is a single Android project with a real module dashboard and safe starter actions.

Included starter modules: Phone Control, Call Assistant, Web Research, Security Center, Wi-Fi Security, Network Security, Password Lab, Email Security, CCTV Security, Cyber Training, Programming Lab, Teach Me, Teach JARVIS, JARVIS Ideas, Tasks & Automation, Knowledge Vault, Screen Control guidance, 3D Character card, Privacy & Permissions, Settings.

Security modules are for the user's own devices/accounts/networks or explicitly authorized labs only.
