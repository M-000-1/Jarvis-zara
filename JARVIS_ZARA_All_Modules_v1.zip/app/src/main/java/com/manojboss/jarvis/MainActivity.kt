package com.manojboss.jarvis
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity: ComponentActivity(){ override fun onCreate(b:Bundle?){super.onCreate(b);setContent{App()}} }
@Composable fun App(){
 var mode by remember{mutableStateOf("JARVIS")}; var cmd by remember{mutableStateOf("")}
 val modules=listOf("AI Core + Voice/Text","Command Engine","Permission & Safety Guard","Phone Control","Screen Control","Call Assistant","Web Research & Browser Agent","Knowledge Vault","Tasks & Automation","Security Center","Wi-Fi Security","Network Security Lab","Password Security Lab","Email Security Center","CCTV Security Center","Cyber Training Lab","Cyber Academy","Programming Lab","Teach JARVIS","Teach Me","JARVIS Ideas","Learning & Progress","3D Character","Profiles & Guest Mode","Diagnostics","Reports & Alerts","Offline Mode","Plugin System","Mission Mode")
 MaterialTheme{Surface(Modifier.fillMaxSize()){Column(Modifier.padding(16.dp)){
 Text("JARVIS / ZARA",style=MaterialTheme.typography.headlineMedium);Text("MANOJ BOSS • ALL MODULES CORE")
 Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button({mode="JARVIS"}){Text("JARVIS")};OutlinedButton({mode="ZARA"}){Text("ZARA")}}
 Text("Active: $mode",Modifier.padding(6.dp));OutlinedTextField(cmd,{cmd=it},label={Text("One command")},Modifier.fillMaxWidth())
 Button({},Modifier.fillMaxWidth()){Text("EXECUTE COMMAND")};Text("MODULES",Modifier.padding(vertical=10.dp),style=MaterialTheme.typography.titleMedium)
 LazyColumn(verticalArrangement=Arrangement.spacedBy(5.dp)){items(modules){m->Card(Modifier.fillMaxWidth()){Text(m,Modifier.padding(12.dp))}}}
}}}}
