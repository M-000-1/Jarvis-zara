# JARVIS / ZARA Full Control Core v5

Mobile-friendly Android starter for Manoj Boss.

This version adds a Full Control Center and voice command routing to official Android control panels. It does not bypass Android security or grant unrestricted control. Permissions and Android restrictions still apply.

Safe command examples: Wi-Fi, Bluetooth, camera, dialer, browser, settings, volume, display, battery, notifications, permissions, accessibility.
