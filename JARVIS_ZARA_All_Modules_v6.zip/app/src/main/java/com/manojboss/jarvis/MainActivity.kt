package com.manojboss.jarvis

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.animation.core.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

data class AppModule(val title: String, val icon: ImageVector, val desc: String)

class MainActivity : ComponentActivity() {
    private val micPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startVoice() else Toast.makeText(this, "Microphone permission is needed for voice input.", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JarvisApp() }
    }

    fun requestVoice() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startVoice()
        else micPermission.launch(Manifest.permission.RECORD_AUDIO)
    }

    private fun startVoice() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Voice recognition is not available on this phone.", Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak a JARVIS command")
        }
        startActivityForResult(intent, 101)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 101) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) {
                routeVoiceCommand(this, spoken)
            }
        }
    }
}

private fun routeVoiceCommand(context: Context, raw: String) {
    val c = raw.lowercase(Locale.getDefault())
    val intent = when {
        c.contains("wifi") || c.contains("wi-fi") -> Intent(Settings.ACTION_WIFI_SETTINGS)
        c.contains("bluetooth") -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
        c.contains("volume") || c.contains("sound") -> Intent(Settings.ACTION_SOUND_SETTINGS)
        c.contains("display") || c.contains("brightness") -> Intent(Settings.ACTION_DISPLAY_SETTINGS)
        c.contains("battery") -> Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)
        c.contains("notification") -> Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply { putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName) }
        c.contains("permission") -> Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
        c.contains("accessibility") || c.contains("screen control") -> Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        c.contains("camera") -> Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
        c.contains("call") || c.contains("dialer") || c.contains("phone") -> Intent(Intent.ACTION_DIAL)
        c.contains("browser") || c.contains("chrome") || c.contains("internet") || c.contains("web") -> Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/"))
        c.contains("setting") -> Intent(Settings.ACTION_SETTINGS)
        else -> null
    }
    if (intent == null) {
        Toast.makeText(context, "Command received: $raw\nTry: Wi-Fi, Bluetooth, camera, dialer, settings, volume, display, battery, browser or permissions.", Toast.LENGTH_LONG).show()
    } else {
        try { context.startActivity(intent) } catch (_: Exception) { Toast.makeText(context, "That Android control is not available on this device.", Toast.LENGTH_SHORT).show() }
    }
}

@Composable
fun JarvisApp() {
    val context = LocalContext.current
    var zara by remember { mutableStateOf(true) }
    var selected by remember { mutableStateOf<AppModule?>(null) }
    var password by remember { mutableStateOf("") }

    val modules = listOf(
        AppModule("Full Control Center", Icons.Default.Tune, "Phone controls and permission access"),
        AppModule("Phone Control", Icons.Default.PhoneAndroid, "Open supported Android settings"),
        AppModule("Call Assistant", Icons.Default.Call, "Open the normal phone dialer"),
        AppModule("Web Research", Icons.Default.Language, "Open browser research"),
        AppModule("Security Center", Icons.Default.Security, "Basic privacy checks"),
        AppModule("Wi-Fi Security", Icons.Default.Wifi, "Open Wi-Fi settings"),
        AppModule("Network Security", Icons.Default.Hub, "Authorized lab guidance"),
        AppModule("Password Lab", Icons.Default.Password, "Local password strength check"),
        AppModule("Email Security", Icons.Default.Email, "MFA and phishing guidance"),
        AppModule("CCTV Security", Icons.Default.Videocam, "Own/authorized camera guidance"),
        AppModule("Cyber Training", Icons.Default.School, "Safe defensive cyber lab"),
        AppModule("Programming Lab", Icons.Default.Code, "Programming learning hub"),
        AppModule("Teach Me", Icons.Default.AutoStories, "JARVIS teaches you"),
        AppModule("Teach JARVIS", Icons.Default.Psychology, "Add your own learning notes"),
        AppModule("JARVIS Ideas", Icons.Default.Lightbulb, "Future improvement ideas"),
        AppModule("Tasks & Automation", Icons.Default.TaskAlt, "Safe reminders and routines"),
        AppModule("Knowledge Vault", Icons.Default.Bookmark, "Save notes and research"),
        AppModule("Screen Control", Icons.Default.TouchApp, "Accessibility-based controls"),
        AppModule("3D Character", Icons.Default.Face, "Mini assistant character"),
        AppModule("Privacy & Permissions", Icons.Default.Lock, "Review app permissions"),
        AppModule("Settings", Icons.Default.Settings, "Assistant settings")
    )

    MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF00E676), background = Color(0xFF05070A), surface = Color(0xFF0B1117))) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFF05070A)) {
            if (selected == null) Dashboard(context, zara, { zara = it }, modules) { selected = it }
            else ModuleScreen(selected!!, password, { password = it }, { selected = null }, context)
        }
    }
}

@Composable
fun Dashboard(context: Context, zara: Boolean, onMode: (Boolean) -> Unit, modules: List<AppModule>, onModule: (AppModule) -> Unit) {
    val activity = context as MainActivity
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("JARVIS // PERSONAL CYBER CORE", color = Color(0xFF00E676), fontSize = 20.sp, fontWeight = FontWeight.Bold)
            IconButton({ onModule(AppModule("Full Control Center", Icons.Default.Tune, "Phone controls and permission access")) }) { Icon(Icons.Default.Settings, "Settings", tint = Color(0xFF00E676)) }
        }
        Text("MANOJ BOSS", color = Color.White)
        Spacer(Modifier.height(14.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1117)), shape = RoundedCornerShape(28.dp)) {
            Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(if (zara) "ZARA" else "JARVIS", color = Color(0xFF00E676), fontSize = 32.sp, fontWeight = FontWeight.Bold)
                Text("ONLINE • FULL CONTROL CORE", color = Color(0xFF00E676))
                Spacer(Modifier.height(10.dp))
                Row {
                    Button({ onMode(false) }) { Text("JARVIS 🤖") }
                    Spacer(Modifier.width(8.dp))
                    Button({ onMode(true) }) { Text("ZARA 👩") }
                }
                Spacer(Modifier.height(8.dp))
                Button({ activity.requestVoice() }, modifier = Modifier.fillMaxWidth()) { Text("🎙 VOICE COMMAND") }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("MODULES", color = Color(0xFF00E676), fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Spacer(Modifier.height(6.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(2), verticalArrangement = Arrangement.spacedBy(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxSize()) {
            items(modules) { m ->
                Card(modifier = Modifier.fillMaxWidth().clickable { onModule(m) }, colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1117))) {
                    Column(Modifier.padding(14.dp)) {
                        Icon(m.icon, null, tint = Color(0xFF00E676))
                        Spacer(Modifier.height(6.dp))
                        Text(m.title, color = Color.White, fontWeight = FontWeight.Bold)
                        Text(m.desc, color = Color.LightGray, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun ModuleScreen(module: AppModule, password: String, onPassword: (String) -> Unit, back: () -> Unit, context: Context) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(back) { Icon(Icons.Default.ArrowBack, "Back", tint = Color.White) }
            Text(module.title, color = Color(0xFF00E676), fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(10.dp))
        when (module.title) {
            "Full Control Center" -> FullControlCenter(context)
            "Phone Control" -> ActionCard("Open Android Settings", "Official Android settings screen.") { context.startActivity(Intent(Settings.ACTION_SETTINGS)) }
            "Call Assistant" -> ActionCard("Open Phone Dialer", "Uses the normal Android dialer; no hidden recording.") { context.startActivity(Intent(Intent.ACTION_DIAL)) }
            "Web Research" -> ActionCard("Open Browser", "Start a web search.") { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=JARVIS+research"))) }
            "Security Center" -> InfoCard("Privacy Check", "Microphone: ${permissionState(context, Manifest.permission.RECORD_AUDIO)}\nCamera: ${permissionState(context, Manifest.permission.CAMERA)}\n\nA normal Android app cannot inspect every security setting.")
            "Wi-Fi Security" -> ActionCard("Open Wi-Fi Settings", "Review your own network settings.") { context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) }
            "Network Security" -> InfoCard("Authorized Lab Only", "Use only on your own devices or explicitly authorized labs. Future versions can add safe inventory and configuration checks.")
            "Password Lab" -> {
                OutlinedTextField(password, onPassword, label = { Text("Test password") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(10.dp)); Text("Strength: ${passwordScore(password)}", color = Color(0xFF00E676), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Local strength analysis only; no password cracking.", color = Color.LightGray)
            }
            "Email Security" -> InfoCard("Email Security", "Enable MFA/2FA, review recovery options, recent security alerts and connected apps. Use your provider's official security controls.")
            "CCTV Security" -> InfoCard("Own / Authorized Cameras", "Use unique passwords, updates and official recovery/reset procedures. No unauthorized access.")
            "Cyber Training" -> InfoCard("Safe Cyber Lab", "Practice on dummy targets, CTFs, your own devices or explicitly authorized labs.")
            "Programming Lab" -> InfoCard("Programming", "Learn Python, Kotlin/Java, JavaScript, HTML/CSS, SQL, Linux basics and Git.")
            "Teach Me" -> InfoCard("Teach Me", "JARVIS can teach topics step-by-step, including programming, history, psychology and defensive cybersecurity.")
            "Teach JARVIS" -> InfoCard("Teach JARVIS", "Future versions can save your notes and rules into a local Knowledge Vault.")
            "JARVIS Ideas" -> InfoCard("Ideas", "Next upgrades: persistent memory, richer command routing, tasks, offline commands and expressive character reactions.")
            "Tasks & Automation" -> InfoCard("Safe Automation", "Use reminders and non-sensitive routines. Sensitive actions should require confirmation.")
            "Knowledge Vault" -> InfoCard("Knowledge Vault", "Save research notes, links and learning material for later retrieval.")
            "Screen Control" -> ActionCard("Open Accessibility Settings", "Enable only if you want supported screen/UI assistance.") { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            "3D Character" -> CharacterStudio(zara = true)
            "Privacy & Permissions" -> ActionCard("Open App Settings", "Review JARVIS/ZARA permissions.") { context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))) }
            "Settings" -> FullControlCenter(context)
            else -> InfoCard(module.title, module.desc)
        }
    }
}


@Composable
fun CharacterStudio(zara: Boolean) {
    var happy by remember { mutableStateOf(true) }
    val infinite = rememberInfiniteTransition(label = "character")
    val bob by infinite.animateFloat(
        initialValue = -6f,
        targetValue = 6f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "bob"
    )
    val blink by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = keyframes {
                durationMillis = 3600
                0f at 0
                0f at 3000
                1f at 3060
                0f at 3180
                0f at 3600
            }
        ),
        label = "blink"
    )
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        InfoCard("ZARA 3D-STYLE CHARACTER", "Cute game-style assistant. Tap an expression to change her reaction. This is an in-app character; floating-over-other-apps can be added later with explicit overlay permission.")
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1117)), shape = RoundedCornerShape(28.dp)) {
            Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Canvas(Modifier.fillMaxWidth().height(360.dp)) {
                    val cx = size.width / 2f
                    val cy = size.height / 2f + bob
                    val headR = size.minDimension * 0.22f
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(Color(0xFFFFE6D5), Color(0xFFE9A983)),
                            center = Offset(cx - headR * .25f, cy - headR * .25f),
                            radius = headR * 1.5f
                        ),
                        radius = headR,
                        center = Offset(cx, cy)
                    )
                    // hair / ponytail silhouette
                    drawCircle(Color(0xFF25202A), headR * 1.08f, Offset(cx, cy - headR * .28f))
                    drawCircle(Color(0xFF25202A), headR * .38f, Offset(cx - headR * .95f, cy - headR * .35f))
                    drawCircle(Color(0xFF25202A), headR * .38f, Offset(cx + headR * .95f, cy - headR * .35f))
                    // face on top of hair
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(Color(0xFFFFF1E7), Color(0xFFE8AD88)),
                            center = Offset(cx - headR * .25f, cy - headR * .25f),
                            radius = headR * 1.3f
                        ),
                        radius = headR * .92f,
                        center = Offset(cx, cy)
                    )
                    val eyeY = cy - headR * .08f
                    val eyeH = if (blink > .5f) 3f else headR * .12f
                    drawRoundRect(Color(0xFF16151A), topLeft = Offset(cx - headR * .48f, eyeY - eyeH / 2), size = androidx.compose.ui.geometry.Size(headR * .28f, eyeH), cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f, 6f))
                    drawRoundRect(Color(0xFF16151A), topLeft = Offset(cx + headR * .20f, eyeY - eyeH / 2), size = androidx.compose.ui.geometry.Size(headR * .28f, eyeH), cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f, 6f))
                    // smile / neutral mouth
                    val mouth = Path().apply {
                        moveTo(cx - headR * .25f, cy + headR * .38f)
                        if (happy) {
                            quadraticBezierTo(cx, cy + headR * .58f, cx + headR * .25f, cy + headR * .38f)
                        } else {
                            quadraticBezierTo(cx, cy + headR * .28f, cx + headR * .25f, cy + headR * .38f)
                        }
                    }
                    drawPath(mouth, Color(0xFF7D3145), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 7f))
                    // neck + futuristic outfit
                    drawRoundRect(Color(0xFF5A4B7A), Offset(cx - headR * .28f, cy + headR * .78f), androidx.compose.ui.geometry.Size(headR * .56f, headR * .45f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(18f,18f))
                    drawCircle(Color(0xFF00E676), headR * .13f, Offset(cx, cy + headR * 1.02f))
                    drawRoundRect(Color(0xFF17222B), Offset(cx - headR * .78f, cy + headR * 1.15f), androidx.compose.ui.geometry.Size(headR * 1.56f, headR * .95f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(50f,50f))
                    drawCircle(Color(0xFF00E676), headR * .10f, Offset(cx, cy + headR * 1.55f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button({ happy = true }) { Text("😊 Happy") }
                    Button({ happy = false }) { Text("😐 Serious") }
                }
                Text(if (happy) "ZARA: Ready, Manoj Boss!" else "ZARA: Focus mode ON.", color = Color(0xFF00E676), fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun FullControlCenter(context: Context) {
    val controls = listOf(
        Triple("System Settings", "Main Android settings", Intent(Settings.ACTION_SETTINGS)),
        Triple("Wi-Fi", "Network settings", Intent(Settings.ACTION_WIFI_SETTINGS)),
        Triple("Bluetooth", "Bluetooth settings", Intent(Settings.ACTION_BLUETOOTH_SETTINGS)),
        Triple("Sound & Volume", "Sound controls", Intent(Settings.ACTION_SOUND_SETTINGS)),
        Triple("Display & Brightness", "Display settings", Intent(Settings.ACTION_DISPLAY_SETTINGS)),
        Triple("Battery", "Battery / power settings", Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)),
        Triple("App Permissions", "JARVIS app permissions", Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))),
        Triple("Notifications", "JARVIS notifications", Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply { putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName) }),
        Triple("Accessibility", "Screen-control access", Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)),
        Triple("Camera", "Open system camera", Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)),
        Triple("Dialer", "Open normal phone dialer", Intent(Intent.ACTION_DIAL)),
        Triple("Browser", "Open web browser", Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/")))
    )
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        InfoCard("Full Control Center", "JARVIS can open these official Android control panels. Android decides which controls are available; sensitive access always requires your permission.")
        controls.forEach { (title, desc, intent) ->
            ActionCard(title, desc) {
                try { context.startActivity(intent) }
                catch (_: Exception) { Toast.makeText(context, "This control is not available on this device.", Toast.LENGTH_SHORT).show() }
            }
        }
    }
}

@Composable fun ActionCard(title: String, desc: String, action: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1117))) {
        Column(Modifier.padding(18.dp)) { Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold); Text(desc, color = Color.LightGray); Spacer(Modifier.height(10.dp)); Button(action) { Text("OPEN / RUN") } }
    }
}

@Composable fun InfoCard(title: String, desc: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1117))) {
        Column(Modifier.padding(18.dp)) { Text(title, color = Color(0xFF00E676), fontSize = 20.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp)); Text(desc, color = Color.White, fontSize = 16.sp) }
    }
}

fun permissionState(context: Context, permission: String): String = if (context.checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED) "GRANTED" else "NOT GRANTED"

fun passwordScore(p: String): String {
    if (p.isEmpty()) return "Enter a password"
    var s = 0
    if (p.length >= 8) s++
    if (p.length >= 12) s++
    if (p.any { it.isUpperCase() }) s++
    if (p.any { it.isLowerCase() }) s++
    if (p.any { it.isDigit() }) s++
    if (p.any { !it.isLetterOrDigit() }) s++
    return when { s <= 2 -> "Weak"; s <= 4 -> "Medium"; else -> "Strong" }
}
