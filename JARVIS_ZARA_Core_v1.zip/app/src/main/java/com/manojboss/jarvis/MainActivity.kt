package com.manojboss.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("en", "IN")
            }
        }

        setContent {
            JarvisApp(
                speak = { text ->
                    tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
                }
            )
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
fun JarvisApp(speak: (String) -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var assistant by remember { mutableStateOf("JARVIS") }
    var status by remember { mutableStateOf("ONLINE") }
    var lastCommand by remember { mutableStateOf("Waiting for Manoj Boss…") }
    var showSettings by remember { mutableStateOf(false) }

    val speechLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val matches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
        val command = matches?.firstOrNull()
        if (!command.isNullOrBlank()) {
            lastCommand = command
            val response = handleCommand(command, assistant)
            speak(response)
        }
    }

    val micPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startSpeech(speechLauncher)
        else {
            status = "MIC PERMISSION NEEDED"
            speak("Manoj Boss, microphone permission is required for voice commands.")
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Color(0xFF05070A),
            surface = Color(0xFF0B1016),
            primary = Color(0xFF00E676),
            secondary = Color(0xFF00B0FF)
        )
    ) {
        Surface(Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF05070A))
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            "JARVIS // PERSONAL CYBER CORE",
                            color = Color(0xFF00E676),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "MANOJ BOSS",
                            color = Color.White,
                            fontSize = 13.sp
                        )
                    }
                    TextButton(onClick = { showSettings = !showSettings }) {
                        Text("SETTINGS")
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .background(Color(0xFF0B1016), RoundedCornerShape(24.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier
                                .size(86.dp)
                                .background(Color(0xFF063D2B), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                if (assistant == "JARVIS") "J" else "Z",
                                color = Color(0xFF00E676),
                                fontSize = 42.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("$assistant ONLINE", color = Color.White, fontWeight = FontWeight.Bold)
                        Text(status, color = Color(0xFF00E676), fontSize = 12.sp)
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1016))) {
                    Column(Modifier.padding(16.dp)) {
                        Text("LAST COMMAND", color = Color(0xFF00B0FF), fontSize = 12.sp)
                        Spacer(Modifier.height(6.dp))
                        Text(lastCommand, color = Color.White)
                    }
                }

                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        modifier = Modifier.weight(1f),
                        onClick = {
                            val hasPermission =
                                androidx.core.content.ContextCompat.checkSelfPermission(
                                    context,
                                    Manifest.permission.RECORD_AUDIO
                                ) == PackageManager.PERMISSION_GRANTED
                            if (hasPermission) {
                                startSpeech(speechLauncher)
                            } else {
                                micPermission.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        }
                    ) {
                        Text("VOICE")
                    }
                    OutlinedButton(
                        modifier = Modifier.weight(1f),
                        onClick = {
                            val msg = "Yes, Manoj Boss. $assistant is ready."
                            lastCommand = msg
                            speak(msg)
                        }
                    ) {
                        Text("TEST")
                    }
                }

                if (showSettings) {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF101820))) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("ASSISTANT MODE", color = Color(0xFF00E676), fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(
                                    selected = assistant == "JARVIS",
                                    onClick = { assistant = "JARVIS" },
                                    label = { Text("JARVIS 🤖") }
                                )
                                FilterChip(
                                    selected = assistant == "ZARA",
                                    onClick = { assistant = "ZARA" },
                                    label = { Text("ZARA 👩") }
                                )
                            }
                            Text(
                                "Next modules: 3D character, Teach JARVIS, phone commands, calls, security dashboard and authorized cyber lab.",
                                color = Color.LightGray,
                                fontSize = 12.sp
                            )
                        }
                    }
                }

                Spacer(Modifier.weight(1f))
                Text(
                    "V1 CORE • Voice + Personality + Command Engine foundation",
                    color = Color.Gray,
                    fontSize = 11.sp
                )
            }
        }
    }
}

private fun startSpeech(
    launcher: androidx.activity.result.ActivityResultLauncher<Intent>
) {
    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        putExtra(RecognizerIntent.EXTRA_PROMPT, "Boliye, Manoj Boss…")
    }
    launcher.launch(intent)
}

private fun handleCommand(command: String, assistant: String): String {
    val c = command.lowercase(Locale.getDefault())

    return when {
        c.contains("hello") || c.contains("नमस्ते") || c.contains("हेलो") ->
            "Namaste Manoj Boss. $assistant is ready."
        c.contains("who are you") || c.contains("तुम कौन") ->
            "I am $assistant, your personal assistant."
        c.contains("security") || c.contains("सिक्योरिटी") ->
            "Manoj Boss, Security Center module will be connected in the next build."
        c.contains("learn") || c.contains("सीख") ->
            "Teach Me mode and Teach JARVIS will be added to the learning module."
        else ->
            "Manoj Boss, I heard: $command. Command Engine is ready for the next module."
    }
}
